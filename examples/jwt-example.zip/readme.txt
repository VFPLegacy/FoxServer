Español
1. Ejecutar el servicio
2. Abrir el navegador y escribir http://localhost:8080/login.html

English
1. Start the service
2. Open your browser and navegate to http://localhost:8080/login.html